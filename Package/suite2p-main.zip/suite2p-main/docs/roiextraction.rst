Signal extraction
------------------------------
