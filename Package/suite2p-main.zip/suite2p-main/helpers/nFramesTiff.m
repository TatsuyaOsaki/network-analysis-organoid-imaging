function n = nFramesTiff(tiff)
%nFrames find the number of frames in the Tiff

n = nFrames(tiff, 2001);
end

