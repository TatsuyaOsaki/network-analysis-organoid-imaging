from importlib_metadata import metadata as _metadata


version = _metadata('suite2p')['version']
