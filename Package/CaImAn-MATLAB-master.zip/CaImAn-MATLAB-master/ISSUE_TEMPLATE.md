Please note that the developer of this package is on leave until January 2019 and might not be able to support you.

For better support, please use the template below to submit your issue. When your issue gets resolved please remember to close it.


- **Describe the issue that you are experiencing**



- **Copy error log below**



- **If you're not reporting an error, type your message below**
